package web.model;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;

@Entity
public class Carrinho {

	private Collection<Item> items;
	
	public Carrinho() {
		// TODO Auto-generated constructor stub
	items = new ArrayList<Item>();
	}

	public Collection<Item> getItens() {
		return items;
	}

	public void setItens(Collection<Item> items) {
		this.items = items;
	}
	
	
	
}
