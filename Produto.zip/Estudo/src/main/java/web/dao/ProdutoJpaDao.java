package web.dao;

public class ProdutoJpaDao {

}
