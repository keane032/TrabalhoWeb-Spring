package web.dao;

public interface ProdutoDao {

}
